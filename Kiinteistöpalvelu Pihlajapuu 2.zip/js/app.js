const menu=document.querySelector('#mobile-menu');
const menuLinks=document.querySelector('.navbar_menu');

menu.addEventListener('click', function(){
    menu.classList.toggle('is-active')
    menuLinks.classList.toggle('active')
});

window.onload = function() {
    /*const pageHeight = document.documentElement.offsetHeight;*/
    document.body.style.height = window.innerHeight + "px";
    document.body.style.background = `linear-gradient(#141414 120px,#444,#141414 ${window.innerHeight - 120}px)`;
}